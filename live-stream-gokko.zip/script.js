const $ = (id) => document.getElementById(id);

const state = {
  title: "【LIVE】今日は雑談します！",
  creator: "配信ごっこチャンネル",
  subscribers: 12800,
  viewers: 386,
  likes: 121,
  elapsed: 0,
  avatarData: "",
  posterData: "",
  chatMode: "auto",
  subscribed: false,
  ended: false
};

const botNames = [
  "あおい", "ゆう", "たこ焼き", "ねこまる", "Kaito", "しろくま",
  "みかん", "そら", "はる", "たけ", "mame", "りんご", "名無しの視聴者"
];

const botMessages = [
  "きたああああ！",
  "こんばんは！",
  "待ってました",
  "今来た",
  "この配信好き",
  "今日もやってる！",
  "こんばんは〜",
  "音量ちょうどいい！",
  "これ何時までやる？",
  "コメント多くて草",
  "初見です",
  "おもしろいｗ",
  "登録者すごい",
  "高評価押した！",
  "ここから見る",
  "今日のタイトル好き",
  "配信ありがとうございます",
  "ｷﾀ━━━━(ﾟ∀ﾟ)━━━━!!"
];

let avatarObjectUrl = null;
let posterObjectUrl = null;
let timerId = null;
let viewerId = null;
let chatId = null;

function formatNumber(n) {
  return Number(n || 0).toLocaleString("ja-JP");
}

function formatTime(sec) {
  const h = Math.floor(sec / 3600).toString().padStart(2, "0");
  const m = Math.floor((sec % 3600) / 60).toString().padStart(2, "0");
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${h}:${m}:${s}`;
}

function makeInitialAvatar(name) {
  const first = [...(name || "配信")][0] || "配";
  const colors = ["#3a3a3a","#4f3f55","#33495f","#4d4b38","#374f48"];
  const idx = [...(name || "")].reduce((a,c)=>a+c.charCodeAt(0),0) % colors.length;
  return { text:first, color:colors[idx] };
}

function setAvatarImage(element, dataUrl, alt = "") {
  if (dataUrl) {
    element.innerHTML = "";
    element.style.backgroundImage = `url("${dataUrl}")`;
    element.style.backgroundSize = "cover";
    element.style.backgroundPosition = "center";
    element.textContent = "";
    element.alt = alt;
  } else {
    const a = makeInitialAvatar(state.creator);
    element.style.backgroundImage = "none";
    element.style.backgroundColor = a.color;
    element.textContent = a.text;
    element.alt = alt;
  }
}

function syncSetupAvatar() {
  setAvatarImage($("setupAvatar"), state.avatarData);
}

function syncUI() {
  $("playerTitle").textContent = state.title;
  $("infoTitle").textContent = state.title;
  $("streamCreator").textContent = state.creator;
  $("streamSubs").textContent = formatNumber(state.subscribers);
  $("likesCount").textContent = formatNumber(state.likes);
  $("playerViewers").textContent = formatNumber(state.viewers);
  $("descriptionViewers").textContent = formatNumber(state.viewers);

  setAvatarImage($("streamAvatar"), state.avatarData, state.creator);
  setAvatarImage($("userAvatarSmall"), state.avatarData);

  if (state.posterData) {
    $("playerBackground").style.backgroundImage = `url("${state.posterData}")`;
    $("playerBackground").style.backgroundSize = "cover";
    $("playerBackground").style.backgroundPosition = "center";
  }
}

function showToast(text) {
  const t = $("toast");
  t.textContent = text;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 1800);
}

function addChat(name, message, {creator=false, donation=false} = {}) {
  const row = document.createElement("div");
  row.className = "chat-line" + (creator ? " creator" : "");
  if (donation) row.style.background = "#251f12";

  const avatar = document.createElement("div");
  avatar.className = "avatar avatar-sm avatar-placeholder";
  if (creator && state.avatarData) {
    setAvatarImage(avatar, state.avatarData);
  } else {
    const a = makeInitialAvatar(name);
    avatar.style.background = a.color;
    avatar.textContent = a.text;
  }

  const body = document.createElement("div");
  body.innerHTML = `<div><span class="chat-name">${escapeHtml(name)}</span>${donation ? '<span style="font-size:11px;color:#e3b44a;font-weight:800"> Super Chat風</span>' : ''}</div>
                   <div class="chat-text">${escapeHtml(message)}</div>`;
  row.appendChild(avatar);
  row.appendChild(body);
  $("chatMessages").appendChild(row);
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;

  // keep DOM light
  while ($("chatMessages").children.length > 80) {
    $("chatMessages").firstChild.remove();
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function seedChat() {
  $("chatMessages").innerHTML = "";
  const seed = [
    ["ねこまる","こんばんは！"],
    ["Kaito","今来た！"],
    ["みかん","今日も配信ありがとう"],
    ["そら","この時間帯好き"],
    ["たこ焼き","高評価押した"],
    ["はる","こんばんは〜"]
  ];
  seed.forEach(([n,m]) => addChat(n,m));
}

function startStream() {
  readFormIntoState();
  state.ended = false;
  $("setupScreen").classList.add("hidden");
  $("streamScreen").classList.remove("hidden");
  $("endModal").classList.add("hidden");
  $("elapsedTime").textContent = "00:00:00";
  $("clockText").textContent = "00:00:00";

  syncUI();
  seedChat();

  clearInterval(timerId);
  clearInterval(viewerId);
  clearInterval(chatId);

  timerId = setInterval(() => {
    state.elapsed += 1;
    $("elapsedTime").textContent = formatTime(state.elapsed);
    $("clockText").textContent = formatTime(state.elapsed);
  }, 1000);

  viewerId = setInterval(() => {
    const delta = Number($("viewerDelta").value);
    const jitter = Math.floor(Math.random() * 11) - 5;
    state.viewers = Math.max(0, state.viewers + delta + jitter);
    if (Math.random() < 0.15) state.viewers = Math.max(0, state.viewers - Math.floor(Math.random()*45));
    syncUI();
  }, 4500);

  scheduleChat();
}

function scheduleChat() {
  clearInterval(chatId);
  if (state.chatMode !== "auto") return;
  const interval = Number($("chatSpeed").value);
  chatId = setInterval(() => {
    const name = botNames[Math.floor(Math.random()*botNames.length)];
    const msg = botMessages[Math.floor(Math.random()*botMessages.length)];
    addChat(name, msg, { donation: Math.random() < 0.04 });
  }, interval);
}

function endStream() {
  clearInterval(timerId);
  clearInterval(viewerId);
  clearInterval(chatId);
  state.ended = true;
  $("endSummary").innerHTML =
    `配信時間 <strong>${formatTime(state.elapsed)}</strong><br>` +
    `最大視聴者数は演出用のため記録していません。<br>` +
    `高評価 <strong>${formatNumber(state.likes)}</strong> ・ 最終視聴者 <strong>${formatNumber(state.viewers)}</strong>人`;
  $("endModal").classList.remove("hidden");
}

function readFormIntoState() {
  state.title = $("titleInput").value.trim() || "【LIVE】配信ごっこ";
  state.creator = $("creatorInput").value.trim() || "配信者";
  state.subscribers = Math.max(0, Number($("subsInput").value) || 0);
  state.viewers = Math.max(0, Number($("viewersInput").value) || 0);
  state.likes = Math.max(0, Number($("likesInput").value) || 0);
  state.chatMode = $("chatModeInput").value;
}

function loadDemo() {
  $("titleInput").value = "【LIVE】深夜の雑談配信！";
  $("creatorInput").value = "しろくま放送局";
  $("subsInput").value = "48200";
  $("viewersInput").value = "1260";
  $("likesInput").value = "683";
  $("chatModeInput").value = "auto";
  showToast("デモ設定を読み込みました");
}

function populateSetupFromState() {
  $("titleInput").value = state.title;
  $("creatorInput").value = state.creator;
  $("subsInput").value = state.subscribers;
  $("viewersInput").value = state.viewers;
  $("likesInput").value = state.likes;
  $("chatModeInput").value = state.chatMode;
  syncSetupAvatar();
}

function makeShareUrl() {
  const cfg = {
    title: state.title,
    creator: state.creator,
    subscribers: state.subscribers,
    viewers: state.viewers,
    likes: state.likes,
    avatarData: state.avatarData,
    posterData: state.posterData,
    chatMode: state.chatMode
  };
  const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(cfg))));
  return `${location.origin}${location.pathname}#config=${encoded}`;
}

async function shareStream() {
  const url = makeShareUrl();
  try {
    await navigator.clipboard.writeText(url);
    $("shareToast").classList.remove("hidden");
    setTimeout(() => $("shareToast").classList.add("hidden"), 1800);
  } catch {
    window.prompt("このリンクをコピーしてください", url);
  }
}

function loadFromHash() {
  const hash = location.hash;
  if (!hash.startsWith("#config=")) return;
  try {
    const encoded = hash.slice(8);
    const cfg = JSON.parse(decodeURIComponent(escape(atob(encoded))));
    Object.assign(state, cfg);
    populateSetupFromState();
  } catch (e) {
    console.warn("share config could not be loaded", e);
  }
}

$("avatarInput").addEventListener("change", () => {
  const file = $("avatarInput").files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    state.avatarData = reader.result;
    syncSetupAvatar();
  };
  reader.readAsDataURL(file);
});

$("posterInput").addEventListener("change", () => {
  const file = $("posterInput").files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    state.posterData = reader.result;
    $("posterPreview").innerHTML = `<img src="${reader.result}" alt="配信背景プレビュー">`;
  };
  reader.readAsDataURL(file);
});

$("startButton").addEventListener("click", startStream);
$("loadDemoButton").addEventListener("click", loadDemo);

$("backToSetup").addEventListener("click", () => {
  clearInterval(timerId);
  clearInterval(viewerId);
  clearInterval(chatId);
  $("streamScreen").classList.add("hidden");
  $("setupScreen").classList.remove("hidden");
  populateSetupFromState();
});

$("endButton").addEventListener("click", endStream);
$("restartButton").addEventListener("click", startStream);
$("editButton").addEventListener("click", () => {
  $("endModal").classList.add("hidden");
  $("streamScreen").classList.add("hidden");
  $("setupScreen").classList.remove("hidden");
  populateSetupFromState();
});

$("likeButton").addEventListener("click", () => {
  state.likes += 1;
  $("likesCount").textContent = formatNumber(state.likes);
  showToast("高評価を追加しました");
});

$("subscribeButton").addEventListener("click", () => {
  state.subscribed = !state.subscribed;
  $("subscribeButton").classList.toggle("subscribed", state.subscribed);
  $("subscribeButton").textContent = state.subscribed ? "登録済み" : "チャンネル登録";
});

$("shareButton").addEventListener("click", shareStream);
$("shareButton2").addEventListener("click", shareStream);

$("clipButton").addEventListener("click", () => showToast("クリップを作成しました（演出）"));
$("saveButton").addEventListener("click", () => showToast("保存しました（演出）"));
$("moreButton").addEventListener("click", () => {
  $("moreButton").textContent = $("moreButton").textContent === "もっと見る" ? "閉じる" : "もっと見る";
});

$("viewerDelta").addEventListener("input", (e) => {
  const v = Number(e.target.value);
  $("viewerDeltaValue").textContent = v >= 0 ? `+${v}` : `${v}`;
});

$("chatSpeed").addEventListener("change", scheduleChat);

$("creatorMessageButton").addEventListener("click", () => {
  const input = $("creatorMessageInput");
  const msg = input.value.trim();
  if (!msg) return;
  addChat(state.creator, msg, {creator:true});
  input.value = "";
});

$("creatorMessageInput").addEventListener("keydown", e => {
  if (e.key === "Enter") $("creatorMessageButton").click();
});

function sendChat() {
  const input = $("chatInput");
  const msg = input.value.trim();
  if (!msg) return;
  addChat("自分", msg);
  input.value = "";
}

$("chatSendButton").addEventListener("click", sendChat);
$("chatInput").addEventListener("keydown", e => {
  if (e.key === "Enter") sendChat();
});

window.addEventListener("load", () => {
  loadFromHash();
  syncSetupAvatar();
});
